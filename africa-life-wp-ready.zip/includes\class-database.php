<?php
if (!defined('ABSPATH')) {
    exit;
}

class AfricaLife_Database {
    
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $submissions_table = $wpdb->prefix . 'africa_life_submissions';
        $plans_table = $wpdb->prefix . 'africa_life_plans';
        $templates_table = $wpdb->prefix . 'africa_life_templates';
        
        $sql = "CREATE TABLE IF NOT EXISTS $submissions_table (
            id int(11) NOT NULL AUTO_INCREMENT,
            agent_id int(11) NOT NULL,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            form_data longtext NOT NULL,
            plan_id int(11) NOT NULL,
            submission_date datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(50) DEFAULT 'Pending',
            pdf_file varchar(500),
            PRIMARY KEY (id),
            KEY agent_id (agent_id),
            KEY plan_id (plan_id),
            KEY status (status)
        ) $charset_collate;";
        
        $sql .= "CREATE TABLE IF NOT EXISTS $plans_table (
            id int(11) NOT NULL AUTO_INCREMENT,
            plan_name varchar(255) NOT NULL,
            categories longtext NOT NULL,
            created_by int(11) NOT NULL,
            created_date datetime DEFAULT CURRENT_TIMESTAMP,
            updated_date datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        $sql .= "CREATE TABLE IF NOT EXISTS $templates_table (
            id int(11) NOT NULL AUTO_INCREMENT,
            template_type varchar(50) NOT NULL,
            template_content longtext NOT NULL,
            logo_path varchar(500),
            updated_by int(11) NOT NULL,
            updated_date datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY template_type (template_type)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        self::insert_default_templates();
        self::insert_sample_plan();
    }
    
    private static function insert_default_templates() {
        global $wpdb;
        
        $templates_table = $wpdb->prefix . 'africa_life_templates';
        
        $email_template = array(
            'customer_subject' => 'Your Africa Life Funeral Cover Application',
            'customer_body' => 'Dear {customer_name},

Thank you for your Africa Life funeral cover application. Please find attached your application form for the {plan_name} plan.

Your selected coverage includes:
{plan_details}

If you have any questions, please contact us.

Best regards,
Africa Life Team',
            'admin_subject' => 'New Funeral Cover Application - {customer_name}',
            'admin_body' => 'A new funeral cover application has been submitted.

Customer Details:
Name: {customer_name}
Email: {customer_email}
Plan: {plan_name}
Agent: {agent_name}
Date: {submission_date}

Please review the attached application form.'
        );
        
        $pdf_template = array(
            'header' => 'AFRICA LIFE APPLICATION FORM',
            'footer' => 'Africa Life - Funeral Cover Application',
            'declaration' => 'I hereby declare that all information provided is true and correct to the best of my knowledge.',
            'font_family' => 'helvetica',
            'font_size' => 10
        );
        
        $script_template = array(
            'content' => '<h3>Agent Script</h3>
<p>Welcome to Africa Life. I\'m here to help you with your funeral cover application.</p>
<p>Let me explain our available plans and help you choose the best coverage for your needs.</p>
<p>I\'ll need to collect some information from you to complete your application.</p>'
        );
        
        $existing_email = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $templates_table WHERE template_type = %s",
            'email'
        ));
        
        if (!$existing_email) {
            $wpdb->insert($templates_table, array(
                'template_type' => 'email',
                'template_content' => json_encode($email_template),
                'updated_by' => get_current_user_id()
            ));
        }
        
        $existing_pdf = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $templates_table WHERE template_type = %s",
            'pdf'
        ));
        
        if (!$existing_pdf) {
            $wpdb->insert($templates_table, array(
                'template_type' => 'pdf',
                'template_content' => json_encode($pdf_template),
                'updated_by' => get_current_user_id()
            ));
        }
        
        $existing_script = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $templates_table WHERE template_type = %s",
            'script'
        ));
        
        if (!$existing_script) {
            $wpdb->insert($templates_table, array(
                'template_type' => 'script',
                'template_content' => json_encode($script_template),
                'updated_by' => get_current_user_id()
            ));
        }
    }
    
    public static function get_submissions($agent_id = null, $status = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'africa_life_submissions';
        $query = "SELECT * FROM $table WHERE 1=1";
        $params = array();
        
        if ($agent_id) {
            $query .= " AND agent_id = %d";
            $params[] = $agent_id;
        }
        
        if ($status) {
            $query .= " AND status = %s";
            $params[] = $status;
        }
        
        $query .= " ORDER BY submission_date DESC";
        
        if (!empty($params)) {
            return $wpdb->get_results($wpdb->prepare($query, $params));
        }
        
        return $wpdb->get_results($query);
    }
    
    public static function get_plans() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'africa_life_plans';
        return $wpdb->get_results("SELECT * FROM $table ORDER BY plan_name ASC");
    }
    
    public static function get_template($type) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'africa_life_templates';
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE template_type = %s",
            $type
        ));
        
        if ($result) {
            $result->template_content = json_decode($result->template_content, true);
        }
        
        return $result;
    }
    
    private static function insert_sample_plan() {
        global $wpdb;
        
        $plans_table = $wpdb->prefix . 'africa_life_plans';
        
        $existing_plan = $wpdb->get_var("SELECT COUNT(*) FROM $plans_table");
        
        if ($existing_plan == 0) {
            $sample_categories = array(
                array(
                    'name' => 'Principal Member',
                    'age_range' => '18-64 years',
                    'rate' => 150.00,
                    'cover_amount' => 25000.00,
                    'terms' => 'Full cover after 6 months waiting period'
                ),
                array(
                    'name' => 'Spouse',
                    'age_range' => '18-64 years',
                    'rate' => 120.00,
                    'cover_amount' => 20000.00,
                    'terms' => 'Full cover after 6 months waiting period'
                ),
                array(
                    'name' => 'Child (14-21 years)',
                    'age_range' => '14-21 years',
                    'rate' => 50.00,
                    'cover_amount' => 10000.00,
                    'terms' => 'Full cover after 3 months waiting period'
                ),
                array(
                    'name' => 'Child (6-13 years)',
                    'age_range' => '6-13 years',
                    'rate' => 30.00,
                    'cover_amount' => 5000.00,
                    'terms' => 'Full cover after 3 months waiting period'
                ),
                array(
                    'name' => 'Child (1-5 years)',
                    'age_range' => '1-5 years',
                    'rate' => 25.00,
                    'cover_amount' => 3000.00,
                    'terms' => 'Full cover after 3 months waiting period'
                ),
                array(
                    'name' => 'Extended Family Member',
                    'age_range' => '0-64 years',
                    'rate' => 75.00,
                    'cover_amount' => 15000.00,
                    'terms' => 'Full cover after 6 months waiting period'
                )
            );
            
            $wpdb->insert($plans_table, array(
                'plan_name' => 'Standard Family Cover',
                'categories' => json_encode($sample_categories),
                'created_by' => 1
            ));
        }
    }
}