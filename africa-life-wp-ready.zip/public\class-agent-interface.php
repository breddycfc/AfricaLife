<?php
if (!defined('ABSPATH')) {
    exit;
}

class AfricaLife_Agent_Interface {
    
    public function render_form() {
        $plans = AfricaLife_Database::get_plans();
        
        ob_start();
        ?>
        <div class="africa-life-agent-container bg-black text-white min-h-screen">
            <div class="container mx-auto px-4 py-8">
                <h1 class="text-3xl font-bold text-center mb-8 text-yellow-400">Africa Life Funeral Cover Application</h1>
                
                <!-- Step 1: Plan Selection -->
                <div id="plan-selection-step" class="bg-gray-900 p-6 rounded-lg shadow-lg mb-8">
                    <h2 class="text-2xl font-semibold mb-6 text-yellow-400">Step 1: Select Funeral Cover Plan</h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php foreach ($plans as $plan): ?>
                            <?php
                            $categories = json_decode($plan->categories, true);
                            $total_premium = 0;
                            foreach ($categories as $category) {
                                $total_premium += floatval($category['rate']);
                            }
                            ?>
                            <div class="plan-card bg-gray-800 p-6 rounded-lg border-2 border-gray-700 cursor-pointer hover:border-yellow-400 transition-colors duration-300" 
                                 data-plan-id="<?php echo $plan->id; ?>" 
                                 data-plan-name="<?php echo esc_attr($plan->plan_name); ?>"
                                 data-categories="<?php echo esc_attr($plan->categories); ?>">
                                
                                <h3 class="text-xl font-semibold text-yellow-300 mb-4"><?php echo esc_html($plan->plan_name); ?></h3>
                                
                                <div class="space-y-3 mb-4">
                                    <?php foreach ($categories as $category): ?>
                                        <div class="bg-gray-700 p-3 rounded text-sm">
                                            <div class="flex justify-between items-center">
                                                <span class="font-medium text-gray-200"><?php echo esc_html($category['name']); ?></span>
                                                <span class="text-yellow-400 font-semibold">R<?php echo number_format($category['rate'], 2); ?></span>
                                            </div>
                                            <div class="text-xs text-gray-400 mt-1">
                                                Cover: R<?php echo number_format($category['cover_amount'], 2); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="border-t border-gray-600 pt-3">
                                    <div class="flex justify-between items-center">
                                        <span class="font-semibold">Total Premium:</span>
                                        <span class="text-xl font-bold text-yellow-400">R<?php echo number_format($total_premium, 2); ?></span>
                                    </div>
                                </div>
                                
                                <button class="select-plan-btn w-full mt-4 bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-2 px-4 rounded transition duration-300">
                                    Select This Plan
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Step 2: Application Form (Hidden initially) -->
                <div id="application-form-step" class="hidden">
                    <div class="bg-gray-900 p-6 rounded-lg shadow-lg mb-6">
                        <div class="flex justify-between items-center">
                            <h2 class="text-2xl font-semibold text-yellow-400">Step 2: Application Form</h2>
                            <div class="flex items-center space-x-4">
                                <div class="text-sm">
                                    <span class="text-gray-300">Selected Plan:</span>
                                    <span id="selected-plan-name" class="text-yellow-400 font-semibold"></span>
                                </div>
                                <button id="change-plan-btn" class="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1 rounded text-sm">
                                    Change Plan
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <form id="africa-life-form" class="space-y-6">
                        <?php wp_nonce_field('africa_life_submit', 'africa_life_nonce'); ?>
                        <input type="hidden" id="selected_plan_id" name="plan_id" value="">
                        
                        <!-- Page 1 Fields -->
                        <div class="bg-gray-900 p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-semibold mb-6 text-yellow-400">Applicant Information</h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-medium mb-2">Applicant's Name *</label>
                                    <input type="text" name="applicant_name" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Date (DD/MM/YYYY) *</label>
                                    <input type="date" name="application_date" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Representative Name *</label>
                                    <input type="text" name="representative_name" value="<?php echo esc_attr(wp_get_current_user()->display_name); ?>" readonly 
                                           class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-gray-300 cursor-not-allowed">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Customer Email *</label>
                                    <input type="email" name="customer_email" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Page 2 Fields - Payment Mandate -->
                        <div class="bg-gray-900 p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-semibold mb-6 text-yellow-400">Payment Mandate</h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium mb-2">Account Holder Name *</label>
                                    <input type="text" name="account_holder_name" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-medium mb-2">Address *</label>
                                    <textarea name="address" required rows="3"
                                              class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent"></textarea>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Bank Name *</label>
                                    <input type="text" name="bank_name" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Branch and Code *</label>
                                    <input type="text" name="branch_code" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Account Number *</label>
                                    <input type="text" name="account_number" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Type of Account *</label>
                                    <select name="account_type" required 
                                            class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                        <option value="">Select Account Type</option>
                                        <option value="Savings">Savings</option>
                                        <option value="Checking">Checking</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Contact Number *</label>
                                    <input type="tel" name="contact_number" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Abbreviated Name (as registered with bank) *</label>
                                    <input type="text" name="abbreviated_name" required 
                                           class="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium mb-2">Monthly Premium Amount *</label>
                                    <input type="number" name="premium_amount" id="premium_amount" step="0.01" readonly 
                                           class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-gray-300 cursor-not-allowed">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Plan Details -->
                        <div class="bg-gray-900 p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-semibold mb-6 text-yellow-400">Selected Plan Details</h3>
                            <div id="plan-details-display"></div>
                        </div>
                        
                        <!-- Declaration -->
                        <div class="bg-gray-900 p-6 rounded-lg shadow-lg">
                            <h3 class="text-xl font-semibold mb-6 text-yellow-400">Declaration</h3>
                            <div class="bg-gray-800 p-4 rounded-lg mb-4">
                                <p class="text-gray-300 mb-4">
                                    I hereby declare that all information provided is true and correct to the best of my knowledge. 
                                    I understand the terms and conditions of this funeral cover policy and agree to the monthly debit order payments.
                                </p>
                            </div>
                            
                            <label class="flex items-start">
                                <input type="checkbox" name="verbal_consent" required 
                                       class="mt-1 mr-3 rounded bg-gray-700 border-gray-600 text-yellow-400 focus:ring-yellow-400">
                                <span class="text-sm">I confirm that the customer has given verbal consent to this declaration and understands all terms and conditions</span>
                            </label>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" id="submit-btn" 
                                    class="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold py-4 px-12 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
                                Submit Application
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Agent Dashboard -->
                <div class="mt-12 bg-gray-900 p-6 rounded-lg shadow-lg">
                    <h2 class="text-2xl font-semibold mb-6 text-yellow-400">My Submissions</h2>
                    <div id="submissions-table">
                        <?php echo $this->render_submissions_table(); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Define AJAX URL for agent interface
            var ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
            
            // Plan selection
            $('.plan-card').click(function() {
                var planId = $(this).data('plan-id');
                var planName = $(this).data('plan-name');
                var categories = $(this).data('categories');
                
                selectPlan(planId, planName, categories);
            });
            
            $('.select-plan-btn').click(function(e) {
                e.stopPropagation();
                var planCard = $(this).closest('.plan-card');
                var planId = planCard.data('plan-id');
                var planName = planCard.data('plan-name');
                var categories = planCard.data('categories');
                
                selectPlan(planId, planName, categories);
            });
            
            function selectPlan(planId, planName, categories) {
                $('#selected_plan_id').val(planId);
                $('#selected-plan-name').text(planName);
                
                try {
                    var categoryData = JSON.parse(categories);
                    displayPlanDetails(planName, categoryData);
                    calculatePremium(categoryData);
                } catch (e) {
                    console.error('Error parsing category data:', e);
                }
                
                $('#plan-selection-step').fadeOut(300, function() {
                    $('#application-form-step').fadeIn(300);
                });
            }
            
            function displayPlanDetails(planName, categories) {
                var html = '<h4 class="font-semibold text-yellow-300 mb-4">' + planName + '</h4>';
                html += '<div class="grid grid-cols-1 md:grid-cols-2 gap-4">';
                
                $.each(categories, function(index, category) {
                    html += '<div class="bg-gray-800 p-4 rounded-lg">' +
                        '<h5 class="font-medium text-yellow-300 mb-2">' + category.name + '</h5>' +
                        '<div class="text-sm text-gray-300 space-y-1">' +
                            '<p>Age Range: ' + category.age_range + '</p>' +
                            '<p>Premium: R' + parseFloat(category.rate).toFixed(2) + '</p>' +
                            '<p>Cover Amount: R' + parseFloat(category.cover_amount).toFixed(2) + '</p>' +
                            '<p>Terms: ' + (category.terms || 'Standard terms apply') + '</p>' +
                        '</div>' +
                    '</div>';
                });
                
                html += '</div>';
                $('#plan-details-display').html(html);
            }
            
            function calculatePremium(categories) {
                var total = 0;
                $.each(categories, function(index, category) {
                    total += parseFloat(category.rate);
                });
                $('#premium_amount').val(total.toFixed(2));
            }
            
            // Change plan
            $('#change-plan-btn').click(function() {
                $('#application-form-step').fadeOut(300, function() {
                    $('#plan-selection-step').fadeIn(300);
                    $('#africa-life-form')[0].reset();
                });
            });
            
            // Form submission
            $('#africa-life-form').submit(function(e) {
                e.preventDefault();
                
                var submitBtn = $('#submit-btn');
                var originalText = submitBtn.text();
                
                submitBtn.prop('disabled', true).html('<div class="inline-block animate-spin mr-2">⟳</div>Submitting...');
                
                var formData = new FormData(this);
                formData.append('action', 'africa_life_submit_form');
                
                $.ajax({
                    url: ajaxUrl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            showNotification('Application submitted successfully! PDF has been generated and emails sent.', 'success');
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            showNotification('Error: ' + (response.data || 'Unknown error'), 'error');
                        }
                    },
                    error: function() {
                        showNotification('An error occurred while submitting the form.', 'error');
                    },
                    complete: function() {
                        submitBtn.prop('disabled', false).text(originalText);
                    }
                });
            });
            
            function showNotification(message, type) {
                var bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
                var notification = $('<div class="fixed top-4 right-4 z-50 p-4 rounded-lg text-white ' + bgColor + ' shadow-lg transform translate-x-full transition-transform duration-300">' +
                    '<div class="flex items-center">' +
                        '<span>' + message + '</span>' +
                        '<button class="ml-4 text-xl leading-none" onclick="$(this).parent().parent().fadeOut()">&times;</button>' +
                    '</div>' +
                '</div>');
                
                $('body').append(notification);
                
                setTimeout(function() {
                    notification.removeClass('translate-x-full');
                }, 100);
                
                setTimeout(function() {
                    notification.addClass('translate-x-full');
                    setTimeout(function() {
                        notification.remove();
                    }, 300);
                }, 5000);
            }
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    private function render_submissions_table() {
        $agent_id = get_current_user_id();
        $submissions = AfricaLife_Database::get_submissions($agent_id);
        
        if (empty($submissions)) {
            return '<div class="text-center py-8"><p class="text-gray-400">No submissions found.</p></div>';
        }
        
        ob_start();
        ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-300">
                <thead class="text-xs text-gray-400 uppercase bg-gray-800">
                    <tr>
                        <th class="px-6 py-3 rounded-tl-lg">Customer Name</th>
                        <th class="px-6 py-3">Plan</th>
                        <th class="px-6 py-3">Date</th>
                        <th class="px-6 py-3">Status</th>
                        <th class="px-6 py-3 rounded-tr-lg">PDF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr class="bg-gray-800 border-b border-gray-700 hover:bg-gray-750 transition-colors duration-200">
                            <td class="px-6 py-4 font-medium text-white">
                                <?php echo esc_html($submission->customer_name); ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php
                                $plan = $this->get_plan_name($submission->plan_id);
                                echo esc_html($plan);
                                ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php echo esc_html(date('Y-m-d H:i', strtotime($submission->submission_date))); ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php
                                $status_class = '';
                                switch($submission->status) {
                                    case 'Approved':
                                        $status_class = 'bg-green-900 text-green-300';
                                        break;
                                    case 'Declined':
                                        $status_class = 'bg-red-900 text-red-300';
                                        break;
                                    default:
                                        $status_class = 'bg-yellow-900 text-yellow-300';
                                }
                                ?>
                                <span class="px-3 py-1 text-xs rounded-full <?php echo $status_class; ?>">
                                    <?php echo esc_html($submission->status); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <?php if ($submission->pdf_file): ?>
                                    <a href="<?php echo esc_url(wp_upload_dir()['baseurl'] . '/africa-life/' . $submission->pdf_file); ?>" 
                                       target="_blank" class="text-yellow-400 hover:text-yellow-300 transition-colors duration-200">
                                        View PDF
                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-500">N/A</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function get_plan_name($plan_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'africa_life_plans';
        $plan = $wpdb->get_row($wpdb->prepare(
            "SELECT plan_name FROM $table WHERE id = %d",
            $plan_id
        ));
        
        return $plan ? $plan->plan_name : 'Unknown Plan';
    }
}