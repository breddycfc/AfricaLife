<?php
if (!defined('ABSPATH')) {
    exit;
}

class AfricaLife_PDF_Generator {
    
    public function generate_pdf($submission_id, $form_data) {
        try {
            $pdf_template = AfricaLife_Database::get_template('pdf');
            $template_settings = $pdf_template ? $pdf_template->template_content : $this->get_default_template_settings();
            
            $plan_id = isset($form_data['plan_id']) ? intval($form_data['plan_id']) : 0;
            $plan_data = $this->get_plan_data($plan_id);
            
            $html_content = $this->generate_html_content($form_data, $plan_data, $template_settings);
            
            $upload_dir = wp_upload_dir();
            $africa_life_dir = $upload_dir['basedir'] . '/africa-life/';
            
            if (!file_exists($africa_life_dir)) {
                wp_mkdir_p($africa_life_dir);
            }
            
            $filename = 'application_' . $submission_id . '_' . date('Y-m-d_H-i-s') . '.html';
            $file_path = $africa_life_dir . $filename;
            
            file_put_contents($file_path, $html_content);
            
            if (class_exists('DOMDocument') && class_exists('XSLTProcessor')) {
                $pdf_filename = $this->convert_html_to_pdf($file_path, $submission_id);
                if ($pdf_filename) {
                    return $pdf_filename;
                }
            }
            
            return $filename;
            
        } catch (Exception $e) {
            error_log('PDF Generation Error: ' . $e->getMessage());
            return false;
        }
    }
    
    private function get_default_template_settings() {
        return array(
            'header' => 'AFRICA LIFE APPLICATION FORM',
            'footer' => 'Africa Life - Funeral Cover Application',
            'declaration' => 'I hereby declare that all information provided is true and correct to the best of my knowledge.',
            'font_family' => 'Arial, sans-serif',
            'font_size' => '12px'
        );
    }
    
    private function get_plan_data($plan_id) {
        global $wpdb;
        
        $plans_table = $wpdb->prefix . 'africa_life_plans';
        $plan = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $plans_table WHERE id = %d",
            $plan_id
        ));
        
        if ($plan) {
            $plan->categories = json_decode($plan->categories, true);
        }
        
        return $plan;
    }
    
    private function generate_html_content($form_data, $plan_data, $template_settings) {
        $signature = $this->generate_signature($form_data['applicant_name']);
        
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Africa Life Application Form</title>
    <style>
        body {
            font-family: ' . $template_settings['font_family'] . ';
            font-size: ' . $template_settings['font_size'] . ';
            line-height: 1.4;
            margin: 20px;
        }
        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 30px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
        }
        .page-title {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin: 20px 0;
            background-color: #f0f0f0;
            padding: 10px;
        }
        .form-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .form-table td, .form-table th {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        .form-table th {
            background-color: #f0f0f0;
            font-weight: bold;
        }
        .signature-box {
            border: 1px solid #000;
            padding: 20px;
            margin: 20px 0;
            min-height: 50px;
        }
        .signature {
            font-style: italic;
            font-size: 16px;
            border-bottom: 1px solid #000;
            display: inline-block;
            min-width: 200px;
            padding-bottom: 5px;
        }
        .declaration {
            border: 2px solid #000;
            padding: 15px;
            margin: 20px 0;
            background-color: #f9f9f9;
        }
        .footer {
            text-align: center;
            font-size: 10px;
            margin-top: 30px;
            border-top: 1px solid #000;
            padding-top: 10px;
        }
        .page-break {
            page-break-before: always;
        }
        .plan-details {
            background-color: #f5f5f5;
            padding: 15px;
            border: 1px solid #ccc;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <div class="header">' . esc_html($template_settings['header']) . '</div>
    
    <!-- Page 1 -->
    <div class="page-title">PAGE 1 - APPLICANT INFORMATION</div>
    
    <table class="form-table">
        <tr>
            <td width="30%"><strong>Applicant\'s Name:</strong></td>
            <td>' . esc_html($form_data['applicant_name']) . '</td>
        </tr>
        <tr>
            <td><strong>Date:</strong></td>
            <td>' . esc_html($form_data['application_date']) . '</td>
        </tr>
        <tr>
            <td><strong>Representative Name:</strong></td>
            <td>' . esc_html($form_data['representative_name']) . '</td>
        </tr>
        <tr>
            <td><strong>Customer Email:</strong></td>
            <td>' . esc_html($form_data['customer_email']) . '</td>
        </tr>
    </table>
    
    <div class="signature-box">
        <strong>APPLICANT SIGNATURE:</strong><br><br>
        <div class="signature">' . esc_html($signature) . '</div><br>
        <small>(Signature based on verbal consent)</small>
    </div>
    
    <div class="declaration">
        <h3 style="text-align: center; margin-top: 0;">DECLARATION</h3>
        <p>' . esc_html($template_settings['declaration']) . '</p>
        <p><small>Customer has provided verbal consent to this declaration.</small></p>
    </div>
    
    <!-- Page 2 -->
    <div class="page-break"></div>
    <div class="page-title">PAGE 2 - PAYMENT MANDATE</div>
    
    <table class="form-table">
        <tr>
            <td width="30%"><strong>Account Holder Name:</strong></td>
            <td>' . esc_html($form_data['account_holder_name']) . '</td>
        </tr>
        <tr>
            <td><strong>Address:</strong></td>
            <td>' . nl2br(esc_html($form_data['address'])) . '</td>
        </tr>
        <tr>
            <td><strong>Bank Name:</strong></td>
            <td>' . esc_html($form_data['bank_name']) . '</td>
        </tr>
        <tr>
            <td><strong>Branch and Code:</strong></td>
            <td>' . esc_html($form_data['branch_code']) . '</td>
        </tr>
        <tr>
            <td><strong>Account Number:</strong></td>
            <td>' . esc_html($form_data['account_number']) . '</td>
        </tr>
        <tr>
            <td><strong>Type of Account:</strong></td>
            <td>' . esc_html($form_data['account_type']) . '</td>
        </tr>
        <tr>
            <td><strong>Contact Number:</strong></td>
            <td>' . esc_html($form_data['contact_number']) . '</td>
        </tr>
        <tr>
            <td><strong>Abbreviated Name:</strong></td>
            <td>' . esc_html($form_data['abbreviated_name']) . '</td>
        </tr>
        <tr>
            <td><strong>Monthly Premium Amount:</strong></td>
            <td>R ' . number_format($form_data['premium_amount'], 2) . '</td>
        </tr>
    </table>';
    
    if ($plan_data) {
        $html .= '<div class="plan-details">
            <h3>SELECTED PLAN: ' . strtoupper(esc_html($plan_data->plan_name)) . '</h3>';
        
        if (!empty($plan_data->categories)) {
            $html .= '<h4>Coverage Details:</h4>
            <table class="form-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Age Range</th>
                        <th>Premium</th>
                        <th>Cover Amount</th>
                    </tr>
                </thead>
                <tbody>';
            
            foreach ($plan_data->categories as $category) {
                $html .= '<tr>
                    <td>' . esc_html($category['name']) . '</td>
                    <td>' . esc_html($category['age_range']) . '</td>
                    <td>R ' . number_format($category['rate'], 2) . '</td>
                    <td>R ' . number_format($category['cover_amount'], 2) . '</td>
                </tr>';
            }
            
            $html .= '</tbody></table>';
        }
        
        $html .= '</div>';
    }
    
    $html .= '<div class="footer">
        ' . esc_html($template_settings['footer']) . '<br>
        Application Generated: ' . date('Y-m-d H:i:s') . '
    </div>
    
</body>
</html>';
        
        return $html;
    }
    
    private function convert_html_to_pdf($html_file, $submission_id) {
        if (function_exists('shell_exec') && !empty(shell_exec('which wkhtmltopdf'))) {
            $upload_dir = wp_upload_dir();
            $africa_life_dir = $upload_dir['basedir'] . '/africa-life/';
            
            $pdf_filename = 'application_' . $submission_id . '_' . date('Y-m-d_H-i-s') . '.pdf';
            $pdf_path = $africa_life_dir . $pdf_filename;
            
            $command = sprintf(
                'wkhtmltopdf --page-size A4 --margin-top 0.75in --margin-right 0.75in --margin-bottom 0.75in --margin-left 0.75in --encoding UTF-8 --quiet %s %s',
                escapeshellarg($html_file),
                escapeshellarg($pdf_path)
            );
            
            $output = shell_exec($command . ' 2>&1');
            
            if (file_exists($pdf_path)) {
                unlink($html_file);
                return $pdf_filename;
            }
        }
        
        return false;
    }
    
    private function generate_signature($applicant_name) {
        $name_parts = explode(' ', trim($applicant_name));
        
        if (count($name_parts) >= 2) {
            $first_initial = substr($name_parts[0], 0, 1);
            $last_name = end($name_parts);
            return $first_initial . '. ' . $last_name;
        } else {
            return $applicant_name;
        }
    }
}