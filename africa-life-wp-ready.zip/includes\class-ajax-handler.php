<?php
if (!defined('ABSPATH')) {
    exit;
}

class AfricaLife_Ajax_Handler {
    
    public static function init() {
        add_action('wp_ajax_africa_life_submit_form', array(__CLASS__, 'handle_form_submission'));
        add_action('wp_ajax_africa_life_admin_login', array(__CLASS__, 'handle_admin_login'));
        add_action('wp_ajax_nopriv_africa_life_admin_login', array(__CLASS__, 'handle_admin_login'));
        add_action('wp_ajax_africa_life_agent_login', array(__CLASS__, 'handle_agent_login'));
        add_action('wp_ajax_nopriv_africa_life_agent_login', array(__CLASS__, 'handle_agent_login'));
        add_action('wp_ajax_africa_life_update_status', array(__CLASS__, 'handle_status_update'));
        add_action('wp_ajax_africa_life_save_template', array(__CLASS__, 'handle_save_template'));
        add_action('wp_ajax_africa_life_save_plan', array(__CLASS__, 'handle_save_plan'));
        add_action('wp_ajax_africa_life_delete_plan', array(__CLASS__, 'handle_delete_plan'));
        add_action('wp_ajax_africa_life_create_agent', array(__CLASS__, 'handle_create_agent'));
        add_action('wp_ajax_africa_life_delete_agent', array(__CLASS__, 'handle_delete_agent'));
    }
    
    public static function handle_form_submission() {
        if (!wp_verify_nonce($_POST['africa_life_nonce'], 'africa_life_submit')) {
            wp_die('Security check failed');
        }
        
        if (!is_user_logged_in() || !AfricaLife_Roles::user_has_agent_access()) {
            wp_send_json_error('Access denied');
        }
        
        $required_fields = array(
            'applicant_name', 'application_date', 'representative_name', 'customer_email',
            'account_holder_name', 'address', 'bank_name', 'branch_code', 'account_number',
            'account_type', 'contact_number', 'abbreviated_name', 'plan_id', 'premium_amount'
        );
        
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                wp_send_json_error('Please fill all required fields');
            }
        }
        
        if (empty($_POST['verbal_consent'])) {
            wp_send_json_error('Verbal consent is required');
        }
        
        // Additional validation
        $email = sanitize_email($_POST['customer_email']);
        if (!is_email($email)) {
            wp_send_json_error('Please provide a valid email address');
        }
        
        $contact_number = sanitize_text_field($_POST['contact_number']);
        if (!preg_match('/^[\d\s\-\+\(\)]+$/', $contact_number)) {
            wp_send_json_error('Please provide a valid contact number');
        }
        
        $account_number = sanitize_text_field($_POST['account_number']);
        if (!preg_match('/^\d+$/', $account_number)) {
            wp_send_json_error('Account number must contain only digits');
        }
        
        $branch_code = sanitize_text_field($_POST['branch_code']);
        if (!preg_match('/^\d{6}$/', $branch_code)) {
            wp_send_json_error('Branch code must be 6 digits');
        }
        
        $form_data = array(
            'applicant_name' => sanitize_text_field($_POST['applicant_name']),
            'application_date' => sanitize_text_field($_POST['application_date']),
            'representative_name' => sanitize_text_field($_POST['representative_name']),
            'customer_email' => sanitize_email($_POST['customer_email']),
            'account_holder_name' => sanitize_text_field($_POST['account_holder_name']),
            'address' => sanitize_textarea_field($_POST['address']),
            'bank_name' => sanitize_text_field($_POST['bank_name']),
            'branch_code' => sanitize_text_field($_POST['branch_code']),
            'account_number' => sanitize_text_field($_POST['account_number']),
            'account_type' => sanitize_text_field($_POST['account_type']),
            'contact_number' => sanitize_text_field($_POST['contact_number']),
            'abbreviated_name' => sanitize_text_field($_POST['abbreviated_name']),
            'premium_amount' => floatval($_POST['premium_amount']),
            'plan_id' => intval($_POST['plan_id']),
            'verbal_consent' => true
        );
        
        global $wpdb;
        
        $submissions_table = $wpdb->prefix . 'africa_life_submissions';
        
        $result = $wpdb->insert($submissions_table, array(
            'agent_id' => get_current_user_id(),
            'customer_name' => $form_data['applicant_name'],
            'customer_email' => $form_data['customer_email'],
            'form_data' => json_encode($form_data),
            'plan_id' => intval($_POST['plan_id']),
            'status' => 'Pending'
        ));
        
        if ($result === false) {
            wp_send_json_error('Failed to save submission');
        }
        
        $submission_id = $wpdb->insert_id;
        
        $pdf_generator = new AfricaLife_PDF_Generator();
        $pdf_file = $pdf_generator->generate_pdf($submission_id, $form_data);
        
        if ($pdf_file) {
            $wpdb->update($submissions_table, 
                array('pdf_file' => $pdf_file),
                array('id' => $submission_id)
            );
            
            $email_handler = new AfricaLife_Email_Handler();
            $email_handler->send_submission_emails($submission_id, $form_data, $pdf_file);
        }
        
        wp_send_json_success('Application submitted successfully');
    }
    
    public static function handle_admin_login() {
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin_login')) {
            wp_send_json_error('Security check failed');
        }
        
        $username = sanitize_text_field($_POST['username']);
        $password = $_POST['password'];
        
        $user = wp_authenticate($username, $password);
        
        if (is_wp_error($user)) {
            wp_send_json_error('Invalid credentials');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access($user->ID)) {
            wp_send_json_error('Access denied. Administrator role required.');
        }
        
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        
        wp_send_json_success('Login successful');
    }
    
    public static function handle_agent_login() {
        error_log('Africa Life - Agent Login called with data: ' . print_r($_POST, true));
        
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_agent_login')) {
            error_log('Africa Life - Agent login nonce verification failed');
            wp_send_json_error('Security check failed');
        }
        
        $username = sanitize_text_field($_POST['username']);
        $password = $_POST['password'];
        
        error_log('Africa Life - Agent login attempt for username: ' . $username);
        
        $user = wp_authenticate($username, $password);
        
        if (is_wp_error($user)) {
            error_log('Africa Life - Agent authentication failed: ' . $user->get_error_message());
            wp_send_json_error('Invalid credentials');
        }
        
        if (!AfricaLife_Roles::user_has_agent_access($user->ID)) {
            error_log('Africa Life - Agent access denied for user ID: ' . $user->ID);
            wp_send_json_error('Access denied. Agent role required.');
        }
        
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        
        error_log('Africa Life - Agent login successful for user ID: ' . $user->ID);
        wp_send_json_success('Login successful');
    }
    
    public static function handle_status_update() {
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin')) {
            wp_send_json_error('Security check failed');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access()) {
            wp_send_json_error('Access denied');
        }
        
        $submission_id = intval($_POST['submission_id']);
        $status = sanitize_text_field($_POST['status']);
        
        if (!in_array($status, array('Pending', 'Approved', 'Declined'))) {
            wp_send_json_error('Invalid status');
        }
        
        global $wpdb;
        
        $submissions_table = $wpdb->prefix . 'africa_life_submissions';
        
        $result = $wpdb->update($submissions_table,
            array('status' => $status),
            array('id' => $submission_id)
        );
        
        if ($result === false) {
            wp_send_json_error('Failed to update status');
        }
        
        wp_send_json_success('Status updated successfully');
    }
    
    public static function handle_save_template() {
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin')) {
            wp_send_json_error('Security check failed');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access()) {
            wp_send_json_error('Access denied');
        }
        
        $template_type = sanitize_text_field($_POST['template_type']);
        $template_content = $_POST['template_content'];
        
        if (!in_array($template_type, array('email', 'pdf', 'script'))) {
            wp_send_json_error('Invalid template type');
        }
        
        global $wpdb;
        
        $templates_table = $wpdb->prefix . 'africa_life_templates';
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $templates_table WHERE template_type = %s",
            $template_type
        ));
        
        $data = array(
            'template_type' => $template_type,
            'template_content' => json_encode($template_content),
            'updated_by' => get_current_user_id()
        );
        
        if ($existing) {
            $result = $wpdb->update($templates_table, $data, array('template_type' => $template_type));
        } else {
            $result = $wpdb->insert($templates_table, $data);
        }
        
        if ($result === false) {
            wp_send_json_error('Failed to save template');
        }
        
        wp_send_json_success('Template saved successfully');
    }
    
    public static function handle_save_plan() {
        // Add debug logging
        error_log('Africa Life - Save Plan called with data: ' . print_r($_POST, true));
        
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin')) {
            error_log('Africa Life - Plan save nonce verification failed');
            wp_send_json_error('Security check failed');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access()) {
            error_log('Africa Life - Plan save admin access denied');
            wp_send_json_error('Access denied');
        }
        
        $plan_name = sanitize_text_field($_POST['plan_name']);
        $categories = $_POST['categories'];
        
        error_log('Africa Life - Plan name: ' . $plan_name);
        error_log('Africa Life - Categories: ' . print_r($categories, true));
        
        if (empty($plan_name) || empty($categories)) {
            error_log('Africa Life - Missing plan name or categories');
            wp_send_json_error('Plan name and categories are required');
        }
        
        // Validate categories array
        if (!is_array($categories)) {
            error_log('Africa Life - Categories is not an array');
            wp_send_json_error('Categories must be provided as an array');
        }
        
        // Validate each category has required fields
        foreach ($categories as $index => $category) {
            if (empty($category['name']) || empty($category['rate']) || empty($category['cover_amount'])) {
                error_log('Africa Life - Category ' . $index . ' missing required fields');
                wp_send_json_error('Each category must have a name, rate, and cover amount');
            }
            
            if (!is_numeric($category['rate']) || floatval($category['rate']) <= 0) {
                error_log('Africa Life - Category ' . $index . ' has invalid rate');
                wp_send_json_error('Category rates must be positive numbers');
            }
            
            if (!is_numeric($category['cover_amount']) || floatval($category['cover_amount']) <= 0) {
                error_log('Africa Life - Category ' . $index . ' has invalid cover amount');
                wp_send_json_error('Category cover amounts must be positive numbers');
            }
        }
        
        // Check for duplicate plan names
        global $wpdb;
        
        $plans_table = $wpdb->prefix . 'africa_life_plans';
        
        $existing_plan_query = "SELECT id FROM $plans_table WHERE plan_name = %s";
        $params = array($plan_name);
        
        // If updating, exclude the current plan from duplicate check
        if (!empty($_POST['plan_id'])) {
            $existing_plan_query .= " AND id != %d";
            $params[] = intval($_POST['plan_id']);
        }
        
        $existing_plan = $wpdb->get_var($wpdb->prepare($existing_plan_query, $params));
        
        if ($existing_plan) {
            error_log('Africa Life - Plan name already exists: ' . $plan_name);
            wp_send_json_error('A plan with this name already exists. Please choose a different name.');
        }
        
        $data = array(
            'plan_name' => $plan_name,
            'categories' => json_encode($categories),
            'created_by' => get_current_user_id()
        );
        
        error_log('Africa Life - Data to save: ' . print_r($data, true));
        
        if (!empty($_POST['plan_id'])) {
            $plan_id = intval($_POST['plan_id']);
            error_log('Africa Life - Updating plan ID: ' . $plan_id);
            $result = $wpdb->update($plans_table, $data, array('id' => $plan_id));
        } else {
            error_log('Africa Life - Creating new plan');
            $result = $wpdb->insert($plans_table, $data);
        }
        
        if ($result === false) {
            error_log('Africa Life - Database error: ' . $wpdb->last_error);
            wp_send_json_error('Failed to save plan: ' . $wpdb->last_error);
        }
        
        error_log('Africa Life - Plan saved successfully');
        wp_send_json_success('Plan saved successfully');
    }
    
    public static function handle_delete_plan() {
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin')) {
            wp_send_json_error('Security check failed');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access()) {
            wp_send_json_error('Access denied');
        }
        
        $plan_id = intval($_POST['plan_id']);
        
        global $wpdb;
        
        $plans_table = $wpdb->prefix . 'africa_life_plans';
        
        $result = $wpdb->delete($plans_table, array('id' => $plan_id));
        
        if ($result === false) {
            wp_send_json_error('Failed to delete plan');
        }
        
        wp_send_json_success('Plan deleted successfully');
    }
    
    public static function handle_create_agent() {
        // Add debug logging
        error_log('Africa Life - Create Agent called with data: ' . print_r($_POST, true));
        
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin')) {
            error_log('Africa Life - Nonce verification failed');
            wp_send_json_error('Security check failed');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access()) {
            error_log('Africa Life - Admin access denied');
            wp_send_json_error('Access denied');
        }
        
        $username = sanitize_text_field($_POST['username']);
        $email = sanitize_email($_POST['email']);
        $password = $_POST['password'];
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        
        error_log('Africa Life - Sanitized data: username=' . $username . ', email=' . $email . ', first_name=' . $first_name . ', last_name=' . $last_name);
        
        if (empty($username) || empty($email) || empty($password)) {
            error_log('Africa Life - Missing required fields');
            wp_send_json_error('Username, email, and password are required');
        }
        
        if (strlen($password) < 6) {
            error_log('Africa Life - Password too short');
            wp_send_json_error('Password must be at least 6 characters long');
        }
        
        // Check if username or email already exists
        if (username_exists($username)) {
            error_log('Africa Life - Username already exists: ' . $username);
            wp_send_json_error('Username already exists. Please choose a different username.');
        }
        
        if (email_exists($email)) {
            error_log('Africa Life - Email already exists: ' . $email);
            wp_send_json_error('Email already exists. Please use a different email address.');
        }
        
        // Validate email format
        if (!is_email($email)) {
            error_log('Africa Life - Invalid email format: ' . $email);
            wp_send_json_error('Please provide a valid email address.');
        }
        
        $result = AfricaLife_Roles::create_agent($username, $email, $password, $first_name, $last_name);
        
        if (is_wp_error($result)) {
            error_log('Africa Life - Agent creation failed: ' . $result->get_error_message());
            wp_send_json_error($result->get_error_message());
        }
        
        error_log('Africa Life - Agent created successfully with ID: ' . $result);
        wp_send_json_success('Agent created successfully');
    }
    
    public static function handle_delete_agent() {
        if (!wp_verify_nonce($_POST['nonce'], 'africa_life_admin')) {
            wp_send_json_error('Security check failed');
        }
        
        if (!AfricaLife_Roles::user_has_admin_access()) {
            wp_send_json_error('Access denied');
        }
        
        $user_id = intval($_POST['user_id']);
        
        $result = AfricaLife_Roles::delete_agent($user_id);
        
        if (!$result) {
            wp_send_json_error('Failed to delete agent');
        }
        
        wp_send_json_success('Agent deleted successfully');
    }
}