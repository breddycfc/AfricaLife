<?php
if (!defined('ABSPATH')) {
    exit;
}

class AfricaLife_Email_Handler {
    
    public function send_submission_emails($submission_id, $form_data, $pdf_file) {
        $email_template = AfricaLife_Database::get_template('email');
        
        if (!$email_template) {
            error_log('Africa Life: Email template not found');
            return false;
        }
        
        $template_data = $email_template->template_content;
        $plan_id = isset($form_data['plan_id']) ? intval($form_data['plan_id']) : 0;
        $plan_data = $this->get_plan_data($plan_id);
        $agent_data = get_userdata(get_current_user_id());
        
        $placeholders = array(
            '{customer_name}' => $form_data['applicant_name'],
            '{customer_email}' => $form_data['customer_email'],
            '{plan_name}' => $plan_data ? $plan_data->plan_name : 'Unknown Plan',
            '{plan_details}' => $this->format_plan_details($plan_data),
            '{agent_name}' => $agent_data ? $agent_data->display_name : 'Unknown Agent',
            '{submission_date}' => date('Y-m-d H:i:s'),
            '{premium_amount}' => 'R ' . number_format($form_data['premium_amount'], 2)
        );
        
        $upload_dir = wp_upload_dir();
        $pdf_path = $upload_dir['basedir'] . '/africa-life/' . $pdf_file;
        
        $customer_sent = $this->send_customer_email($form_data['customer_email'], $template_data, $placeholders, $pdf_path);
        $admin_sent = $this->send_admin_email($template_data, $placeholders, $pdf_path);
        
        return $customer_sent && $admin_sent;
    }
    
    private function send_customer_email($customer_email, $template_data, $placeholders, $pdf_path) {
        $subject = $this->replace_placeholders($template_data['customer_subject'], $placeholders);
        $message = $this->replace_placeholders($template_data['customer_body'], $placeholders);
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Africa Life <noreply@africanlife.com>'
        );
        
        $attachments = array();
        if (file_exists($pdf_path)) {
            $attachments[] = $pdf_path;
        }
        
        $sent = wp_mail($customer_email, $subject, $this->format_email_content($message), $headers, $attachments);
        
        if (!$sent) {
            error_log('Africa Life: Failed to send customer email to ' . $customer_email);
        }
        
        return $sent;
    }
    
    private function send_admin_email($template_data, $placeholders, $pdf_path) {
        $admin_email = get_option('admin_email');
        $africa_life_admin_email = get_option('africa_life_admin_email', $admin_email);
        
        $subject = $this->replace_placeholders($template_data['admin_subject'], $placeholders);
        $message = $this->replace_placeholders($template_data['admin_body'], $placeholders);
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Africa Life <noreply@africanlife.com>'
        );
        
        $attachments = array();
        if (file_exists($pdf_path)) {
            $attachments[] = $pdf_path;
        }
        
        $sent = wp_mail($africa_life_admin_email, $subject, $this->format_email_content($message), $headers, $attachments);
        
        if (!$sent) {
            error_log('Africa Life: Failed to send admin email to ' . $africa_life_admin_email);
        }
        
        return $sent;
    }
    
    private function replace_placeholders($content, $placeholders) {
        return str_replace(array_keys($placeholders), array_values($placeholders), $content);
    }
    
    private function format_email_content($message) {
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Africa Life</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #1a1a1a;
            color: #fbbf24;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }
        .content {
            background-color: #f9f9f9;
            padding: 30px;
            border-radius: 0 0 5px 5px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Africa Life</h1>
        <p>Funeral Cover Application</p>
    </div>
    <div class="content">
        ' . nl2br(esc_html($message)) . '
    </div>
    <div class="footer">
        <p>&copy; ' . date('Y') . ' Africa Life. All rights reserved.</p>
    </div>
</body>
</html>';
        
        return $html;
    }
    
    private function get_plan_data($plan_id) {
        global $wpdb;
        
        $plans_table = $wpdb->prefix . 'africa_life_plans';
        $plan = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $plans_table WHERE id = %d",
            $plan_id
        ));
        
        if ($plan) {
            $plan->categories = json_decode($plan->categories, true);
        }
        
        return $plan;
    }
    
    private function format_plan_details($plan_data) {
        if (!$plan_data || empty($plan_data->categories)) {
            return 'Plan details not available.';
        }
        
        $details = '';
        foreach ($plan_data->categories as $category) {
            $details .= sprintf(
                "• %s (%s): R%s premium, R%s cover\n",
                $category['name'],
                $category['age_range'],
                number_format($category['rate'], 2),
                number_format($category['cover_amount'], 2)
            );
        }
        
        return $details;
    }
    
    public function send_status_notification($submission_id, $new_status) {
        global $wpdb;
        
        $submissions_table = $wpdb->prefix . 'africa_life_submissions';
        $submission = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $submissions_table WHERE id = %d",
            $submission_id
        ));
        
        if (!$submission) {
            return false;
        }
        
        $form_data = json_decode($submission->form_data, true);
        $agent_data = get_userdata($submission->agent_id);
        
        $subject = 'Application Status Update - ' . $form_data['applicant_name'];
        $message = sprintf(
            "Dear %s,\n\nYour Africa Life funeral cover application status has been updated.\n\nNew Status: %s\n\nApplication Details:\nCustomer: %s\nDate: %s\n\nBest regards,\nAfrica Life Team",
            $agent_data ? $agent_data->display_name : 'Agent',
            $new_status,
            $form_data['applicant_name'],
            $submission->submission_date
        );
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: Africa Life <noreply@africanlife.com>'
        );
        
        $agent_email = $agent_data ? $agent_data->user_email : '';
        if ($agent_email) {
            return wp_mail($agent_email, $subject, $this->format_email_content($message), $headers);
        }
        
        return false;
    }
}